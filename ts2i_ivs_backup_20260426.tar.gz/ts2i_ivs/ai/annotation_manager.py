"""
YOLO annotations + pseudo-labels
"""
