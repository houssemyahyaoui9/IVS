"""
TextureAnalyzer GLCM+LBP+FFT
"""
