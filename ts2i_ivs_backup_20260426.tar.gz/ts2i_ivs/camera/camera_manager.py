"""
CameraManager pluggable
"""
