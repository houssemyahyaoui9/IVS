"""
ConsecutiveNOKWatcher — §41
"""
