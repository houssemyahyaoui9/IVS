"""
Alerts anti-spam
"""
