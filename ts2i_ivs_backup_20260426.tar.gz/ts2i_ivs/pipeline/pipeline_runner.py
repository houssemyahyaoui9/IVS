"""
Main pipeline loop
"""
