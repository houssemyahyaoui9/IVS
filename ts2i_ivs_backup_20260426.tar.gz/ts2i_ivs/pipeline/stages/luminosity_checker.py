"""
LuminosityChecker — §42
"""
