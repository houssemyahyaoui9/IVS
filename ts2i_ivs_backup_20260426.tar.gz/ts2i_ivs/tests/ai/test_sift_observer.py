"""
SiftObserver — G-06
"""
