"""
BarcodeObserver — G-14
"""
