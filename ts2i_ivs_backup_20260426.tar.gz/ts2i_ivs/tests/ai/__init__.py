"""ai tests"""
