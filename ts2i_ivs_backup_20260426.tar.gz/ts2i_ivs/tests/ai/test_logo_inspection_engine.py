"""
MultiLogo — G-24
"""
