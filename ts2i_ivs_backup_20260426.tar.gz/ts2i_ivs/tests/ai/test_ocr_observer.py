"""
OcrObserver — G-14
"""
