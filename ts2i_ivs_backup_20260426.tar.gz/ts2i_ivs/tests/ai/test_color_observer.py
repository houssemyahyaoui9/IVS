"""
ColorObserver — G-09
"""
