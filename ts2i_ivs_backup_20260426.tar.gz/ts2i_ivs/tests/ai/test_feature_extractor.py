"""
FeatureExtractor — G-05
"""
