"""
SurfaceObserver — G-10
"""
