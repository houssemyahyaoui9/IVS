"""
TierPriorityWidget — G-21
"""
