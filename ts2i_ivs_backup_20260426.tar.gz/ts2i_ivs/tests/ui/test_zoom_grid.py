"""
ZoomableGridView — G-23
"""
