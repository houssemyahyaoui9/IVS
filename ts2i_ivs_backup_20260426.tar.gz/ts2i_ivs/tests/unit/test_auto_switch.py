"""
AutoSwitch — G-22
"""
