"""
ConsecutiveNOK — G-27
"""
