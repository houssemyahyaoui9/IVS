"""
RuleEngine — G-12
"""
