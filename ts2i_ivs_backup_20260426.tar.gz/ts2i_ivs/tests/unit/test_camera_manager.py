"""
CameraManager — G-02
"""
