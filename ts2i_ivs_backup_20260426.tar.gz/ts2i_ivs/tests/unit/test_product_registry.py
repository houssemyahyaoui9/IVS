"""
ProductRegistry
"""
