"""
LuminosityChecker — G-28
"""
