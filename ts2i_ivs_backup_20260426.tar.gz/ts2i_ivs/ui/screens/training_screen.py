"""
Entraînement per-Tier
"""
