"""
Overlays Tier-colored
"""
