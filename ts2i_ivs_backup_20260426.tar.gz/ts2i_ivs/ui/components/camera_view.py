"""
Camera live view
"""
