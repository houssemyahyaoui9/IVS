"""
AI Monitor per-Tier
"""
