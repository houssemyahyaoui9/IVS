"""
MemorySystem best/worst/edge
"""
